package com.demievil.library;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ScrollView;

public class RefreshScrollLayout extends SwipeRefreshLayout {

	private final int		mTouchSlop;
	private ScrollView mScrollView;

	private float			firstTouchY;
	private float			lastTouchY;

	private boolean			isLoading	= false;

	public RefreshScrollLayout(Context context) {
		this(context, null);
	}

	public RefreshScrollLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
	}

	//set the child view of RefreshLayout,ListView
	public void setChildView(ScrollView mScrollView) {
		this.mScrollView = mScrollView;
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent event) {
		final int action = event.getAction();
		switch (action) {
		case MotionEvent.ACTION_DOWN:
			firstTouchY = event.getRawY();
			break;

		case MotionEvent.ACTION_UP:
			lastTouchY = event.getRawY();
			if (canLoadMore()) {
				loadData();
			}
			break;
		default:
			break;
		}

		return super.dispatchTouchEvent(event);
	}

	private boolean canLoadMore() {
		return isBottom() && !isLoading && isPullingUp();
	}

	private boolean isBottom() {
		View view = mScrollView.getChildAt(getChildCount() - 1);
		if (null != view) {
			// Calculate the scroll diff
			int diff = (view.getBottom() - (view.getHeight() + view.getScrollY()));

			// if diff is zero, then the bottom has been reached
			if (diff == 0) {
				// notify that we have reached the bottom
				return true;
			}
		}
		return false;
	}

	private boolean isPullingUp() {
		return (firstTouchY - lastTouchY) >= mTouchSlop;
	}

	private void loadData() {
		setLoading(true);
	}

	public void setLoading(boolean loading) {
		if (mScrollView == null)
			return;
		isLoading = loading;
		if (loading) {
			if (isRefreshing()) {
				setRefreshing(false);
			}
		}
		else {
			firstTouchY = 0;
			lastTouchY = 0;
		}
	}

	public interface OnLoadListener {
		public void onLoad();
	}
}